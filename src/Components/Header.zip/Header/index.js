import "./style.css";
import searchicon from './search.svg';
import profileicon from './profile.svg';

function Header() {
    return (
       <div className="headersection">

            <div className="header_container">

                <div className="dropdown">
                        <div className="bar1"></div>
                        <div className="bar1"></div>
                        <div className="bar1"></div>  
                    </div>

                <div className="search_bar_and_name">

                    <div className="search">
                        <img src={searchicon} alt="search_icon" height="35px" width= "30px"/>
                    </div>

                    <div className="header_profile">
                            <img src={profileicon} alt="profile_icon" height="35px" width= "35px"/>
                    </div>

                </div>

            </div>
       </div>
    )
}

export default Header
